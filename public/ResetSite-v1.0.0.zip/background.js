chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "resetSite") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      if (activeTab && activeTab.url) {
        try {
          const url = new URL(activeTab.url);
          const origin = url.origin;
          
          const { cache, cookies, storage } = request.options;
          
          let dataToRemove = {};
          
          if (cache) {
             dataToRemove.cacheStorage = true;
          }
          if (cookies) {
             dataToRemove.cookies = true;
          }
          if (storage) {
             dataToRemove.localStorage = true;
             dataToRemove.indexedDB = true;
             dataToRemove.fileSystems = true;
             dataToRemove.webSQL = true;
             dataToRemove.pluginData = true;
          }
          
          chrome.browsingData.remove({
            "origins": [origin]
          }, dataToRemove, () => {
            // Reload the tab automatically after clearing data
            chrome.tabs.reload(activeTab.id);
            sendResponse({ success: true, origin });
          });
        } catch (e) {
          sendResponse({ success: false, error: e.toString() });
        }
      } else {
        sendResponse({ success: false, error: "No active tab or valid URL" });
      }
    });

    return true; // Keep the message channel open for the async response
  }
});
