document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('start-btn');
  const closeBtn = document.getElementById('close-btn');

  const chkCache = document.getElementById('chk-cache');
  const chkCookies = document.getElementById('chk-cookies');
  const chkStorage = document.getElementById('chk-storage');

  closeBtn.addEventListener('click', () => {
    window.close();
  });

  startBtn.addEventListener('click', () => {
    const options = {
      cache: chkCache.checked,
      cookies: chkCookies.checked,
      storage: chkStorage.checked
    };

    // Prevent click if everything is unchecked
    if (!options.cache && !options.cookies && !options.storage) {
      alert("Please select at least one item to clean.");
      return;
    }

    startBtn.classList.add('loading');
    startBtn.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
      </svg>
      CLEANING...
    `;

    chrome.runtime.sendMessage({ action: "resetSite", options: options }, (response) => {
      setTimeout(() => {
        if (chrome.runtime.lastError || !response || !response.success) {
           startBtn.classList.remove('loading');
           startBtn.innerHTML = `FAILED`;
           startBtn.style.backgroundColor = '#dc2626';
           console.error(chrome.runtime.lastError, response?.error);
        } else {
           startBtn.classList.remove('loading');
           startBtn.innerHTML = `
             <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
               <path d="M20 6L9 17l-5-5"/>
             </svg>
             CLEANED!
           `;
           startBtn.style.backgroundColor = '#16a34a';
           
           setTimeout(() => {
             window.close();
           }, 1500);
        }
      }, 500); // Artificial delay to show the nice animation and state
    });
  });
});
