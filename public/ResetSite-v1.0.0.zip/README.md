# Reset Site Extension

A Chrome extension to instantly clear cookies, local storage, and session data for the active tab.

## How to Test Locally
1. Open Google Chrome
2. Go to `chrome://extensions/`
3. Toggle "Developer mode" on (top right)
4. Click "Load unpacked"
5. Select this exact folder (`site-reset-extension`)
6. The extension is now installed and ready to use! Pin it to your toolbar to test it out.
